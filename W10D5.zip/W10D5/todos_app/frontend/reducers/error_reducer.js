import {RECEIVE_ERRORS, CLEAR_ERRORS } from "../actions/error_actions";

const errorReducer = (state = [], action ) => {
  Object.freeze(state);
  let nextState = []
  
  switch(action.type) {
    case RECEIVE_ERRORS:
      console.log(action.errors);
      return action.errors;
    case CLEAR_ERRORS:
      return state;
      // return nextState;
      // break; // for now
    default:
      return state;
  }
};

export default errorReducer;