// import React from 'react';

export const fetchTodos = () => {
  return $.ajax({
    url: './api/todos',
    method: 'get'
  });
};


export const createTodo = (todo) => {
  return $.ajax({
    url:  './api/todos',
    method: 'post',
    data: {todo}
  });
}

export const updateTodo = (todo)  => {
  return $.ajax({
    url: `./api/todo/${todo.id}`,
    method: 'post',
    data: {todo}
  });
}