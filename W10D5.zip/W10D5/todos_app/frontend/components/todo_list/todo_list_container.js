import { connect } from 'react-redux';
import TodoList from './todo_list';

// Actions
import { createTodo, receiveTodos, receiveTodo, fetchTodos, updateTodo } from '../../actions/todo_actions';
import { receiveErrors, clearErrors } from "../../actions/error_actions";
import { allTodos } from '../../reducers/selectors';

const mapStateToProps = state => ({
  todos: allTodos(state),
  state
});

const mapDispatchToProps = dispatch => ({
  updateTodo: (todo) => dispatch(updateTodo(todo)),
  clearErrors: () => dispatch(clearErrors()),
  receiveErrors: (errors) => dispatch(receiveErrors(errors)),
  receiveTodo: todo => dispatch(receiveTodo(todo)),
  fetchTodos: () => dispatch(fetchTodos()),
  createTodo: (todo) => dispatch(createTodo(todo))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TodoList);
