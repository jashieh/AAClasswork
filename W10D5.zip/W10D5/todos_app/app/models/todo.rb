class Todo < ApplicationRecord
  validates :done, inclusion: { in: [true, false] }
  validates :body, length: { minimum: 6}
end
