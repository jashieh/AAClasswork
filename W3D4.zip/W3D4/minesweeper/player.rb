class Player

    def get_move
        puts "Press f to flag or s to select"
        input = gets.chomp
        if 


    end
end